"""
URL configuration for degree_checklist project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from checklist import views

# added separate pages for each model
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    # used as pages for users to view tables with ability to sort by columns ascending or descending
    path('student/', views.student_list, name='student_list'),
    path('major/', views.major_list, name='major_list'),
    path('enroll/', views.enroll_list, name='enroll_list'),
    path('course/', views.course_list, name='course_list'),
    path('requirement/', views.requirement_list, name='requirement_list'),
    path('major_selection/', views.majorsel_list, name='majorsel_list'),
    path('major_requirement/', views.majorreq_list, name='majorreq_list'),
    path('course_requirement/', views.coursereq_list, name='coursereq_list'),
    # major creation and edit
    path('majors/<int:pk>/', views.major_edit, name='major_edit'),
    path('majors/new/', views.major_edit, name='major_create'),
    # student creation and edit
    path('students/<int:pk>/', views.student_edit, name='student_edit'),
    path('students/new/', views.student_edit, name='student_create'),
    # courses creation and edit
    path('courses/<int:pk>/', views.course_edit, name='course_edit'),
    path('courses/new/', views.course_edit, name='course_create'),
    # course requirement creation and edit
    path('coursereq/<int:pk>/', views.coursereq_edit, name='coursereq_edit'),
    path('coursereq/new/', views.coursereq_edit, name='coursereq_create'),
    # major selection creation and edit
    path('majorsel/new/', views.majorsel_edit, name='majorsel_create'),
    path('majorsel/<int:pk>/', views.majorsel_edit, name='majorsel_edit'),
    # major requirement creation and edit
    path('majorreq/new/', views.majorreq_edit, name='majorreq_create'),
    path('majorreq/<int:pk>/', views.majorreq_edit, name='majorreq_edit'),
    # enroll creation and edit
    path('enroll/new/', views.enroll_edit, name='enroll_create'),
    path('enroll/<int:pk>/', views.enroll_edit, name='enroll_edit'),
    # requirement creation and edit
    path('requirement/new/', views.requirement_edit, name='requirement_create'),
    path('requirement/<int:pk>/', views.requirement_edit, name='requirement_edit'),
]
