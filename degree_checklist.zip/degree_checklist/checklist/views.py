from django.shortcuts import render, get_object_or_404, redirect
from .models import Student, Major, Enroll, Requirement, Course, Major_requirement, Major_selection, Course_requirement
from .forms import MajorForm, CourseForm, StudentForm, MajorReqForm, EnrollForm, MajorSelForm, CourseReqForm, RequirementForm
from django.contrib import messages

# Create your views here.
def index (request):
    return render(request, "base.html")

# student list
# for loop to traverse through objects and add to list
def student_list(request):
    slist = Student.objects.all()
    student_list = []
    for s in slist:
        student_list.append(s)
    context = {'student_list': student_list}
    return render(request,"checklist/student_list.html", context)

# enroll list
# for loop to traverse through objects and add to list
def enroll_list(request):
    elist = Enroll.objects.all()
    enroll_list = []
    for e in elist:
        enroll_list.append(e)
    context = {'enroll_list': enroll_list}
    return render(request,"checklist/enroll_list.html", context)

# course list
# for loop to traverse through objects and add to list
def course_list(request):
    clist = Course.objects.all()
    course_list = []
    for c in clist:
        course_list.append(c)
    context = {'course_list': course_list}
    return render(request,"checklist/course_list.html", context)

# requirement list
# for loop to traverse through objects and add to list
def requirement_list(request):
    rlist = Requirement.objects.all()
    requirement_list = []
    for r in rlist:
        requirement_list.append(r)
    context = {'requirement_list': requirement_list}
    return render(request,"checklist/requirement_list.html", context)

# major selection list
# for loop to traverse through objects and add to list
def majorsel_list(request):
    mslist = Major_selection.objects.all()
    majorsel_list = []
    for ms in mslist:
        majorsel_list.append(ms)
    context = {'majorsel_list': majorsel_list}
    return render(request,"checklist/majorsel_list.html", context)

# major requirement list
# for loop to traverse through objects and add to list
def majorreq_list(request):
    mrlist = Major_requirement.objects.all()
    majorreq_list = []
    for mr in mrlist:
        majorreq_list.append(mr)
    context = {'majorreq_list': majorreq_list}
    return render(request,"checklist/majorreq_list.html", context)

# course requirement list
# for loop to traverse through objects and add to list
def coursereq_list(request):
    crlist = Course_requirement.objects.all()
    coursereq_list = []
    for cr in crlist:
        coursereq_list.append(cr)
    context = {'coursereq_list': coursereq_list}
    return render(request,"checklist/coursereq_list.html", context)

# major list
# for loop to traverse through objects and add to list
def major_list(request):
    mlist = Major.objects.all()
    major_list = []
    for m in mlist:
        major_list.append(m)
    context = {'major_list': major_list}
    return render(request,"checklist/major_list.html", context)

# major creation and edit
def major_edit(request, pk=None):
    if pk is not None:
        major = get_object_or_404(Major, pk=pk)
    else:
        major = None

    if request.method == "POST":
        form = MajorForm(request.POST, instance=major)
        if form.is_valid():
            update_major = form.save()
            if major is None:
                messages.success(request, 'Major "{}" was created.'.format(update_major))
            else:
                messages.success(request, 'Major "{}" was updated.'.format(update_major))

            return redirect("major_edit",update_major.pk)
    else:
        form = MajorForm(instance=major)

    return render(request, "checklist/instance-form.html", {"method": request.method, "form":form, "model_type": "Major", "instance": major,})

# student creation and edit
def student_edit(request, pk=None):
    if pk is not None:
        student = get_object_or_404(Student, pk=pk)
    else:
        student = None

    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            update_student = form.save()
            if student is None:
                messages.success(request, 'Student "{}" was created.'.format(update_student))
            else:
                messages.success(request, 'Student "{}" was updated.'.format(update_student))

            return redirect("student_edit",update_student.pk)
    else:
        form = StudentForm(instance=student)

    return render(request, "checklist/instance-form.html", {"method": request.method, "form":form, "model_type": "Student", "instance": student,})

# course creation and edit
def course_edit(request, pk=None):
    if pk is not None:
        course = get_object_or_404(Course, pk=pk)
    else:
        course = None

    if request.method == "POST":
        form = CourseForm(request.POST, instance=course)
        if form.is_valid():
            update_course = form.save()
            if course is None:
                messages.success(request, 'Course "{}" was created.'.format(update_course))
            else:
                messages.success(request, 'Course "{}" was updated.'.format(update_course))

            return redirect("course_edit",update_course.pk)
    else:
        form = CourseForm(instance=course)

    return render(request, "checklist/instance-form.html", {"method": request.method, "form":form, "model_type": "Course", "instance": course,})

# requirement creation and edit
def requirement_edit(request, pk=None):
    if pk is not None:
        requirement = get_object_or_404(Requirement, pk=pk)
    else:
        requirement = None

    if request.method == "POST":
        form = RequirementForm(request.POST, instance=requirement)
        if form.is_valid():
            update_req = form.save()
            if requirement is None:
                messages.success(request, 'Requirement "{}" was created.'.format(update_req))
            else:
                messages.success(request, 'Requirement "{}" was updated.'.format(update_req))

            return redirect("requirement_edit",update_req.pk)
    else:
        form = RequirementForm(instance=requirement)

    return render(request, "checklist/instance-form.html", {"method": request.method, "form":form, "model_type": "Requirement", "instance": requirement,})

# course requirement creation and edit
def coursereq_edit(request, pk=None):
    if pk is not None:
        coursereq = get_object_or_404(Course_requirement, pk=pk)
    else:
        coursereq = None

    if request.method == "POST":
        form = CourseReqForm(request.POST, instance=coursereq)
        if form.is_valid():
            update_coursereq = form.save()
            if coursereq is None:
                messages.success(request, 'Course Requirement "{}" was created.'.format(update_coursereq))
            else:
                messages.success(request, 'Course Requirement "{}" was updated.'.format(update_coursereq))

            return redirect("coursereq_edit",update_coursereq.pk)
    else:
        form = CourseReqForm(instance=coursereq)

    return render(request, "checklist/instance-form.html", {"method": request.method, "form":form, "model_type": "Course_requirement", "instance": coursereq,})

# enroll creation and edit
def enroll_edit(request, pk=None):
    if pk is not None:
        enroll = get_object_or_404(Enroll, pk=pk)
    else:
        enroll = None

    if request.method == "POST":
        form = EnrollForm(request.POST, instance=enroll)
        if form.is_valid():
            update_enroll = form.save()
            if enroll is None:
                messages.success(request, 'Enrollment "{}" was created.'.format(update_enroll))
            else:
                messages.success(request, 'Enrollment "{}" was updated.'.format(update_enroll))

            return redirect("enroll_edit",update_enroll.pk)
    else:
        form = EnrollForm(instance=enroll)

    return render(request, "checklist/instance-form.html", {"method": request.method, "form":form, "model_type": "Enroll", "instance": enroll,})

# major selection creation and edit
def majorsel_edit(request, pk=None):
    if pk is not None:
        majorsel = get_object_or_404(Major_selection, pk=pk)
    else:
        majorsel = None

    if request.method == "POST":
        form = MajorSelForm(request.POST, instance=majorsel)
        if form.is_valid():
            update_majorsel = form.save()
            if majorsel is None:
                messages.success(request, 'Major Selecion "{}" was created.'.format(update_majorsel))
            else:
                messages.success(request, 'Major Selection "{}" was updated.'.format(update_majorsel))

            return redirect("majorsel_edit",update_majorsel.pk)
    else:
        form = MajorSelForm(instance=majorsel)

    return render(request, "checklist/instance-form.html", {"method": request.method, "form":form, "model_type": "Major_selection", "instance": majorsel,})

# major requirement creation and edit
def majorreq_edit(request, pk=None):
    if pk is not None:
        majorreq = get_object_or_404(Major_requirement, pk=pk)
    else:
        majorreq = None

    if request.method == "POST":
        form = MajorReqForm(request.POST, instance=majorreq)
        if form.is_valid():
            update_majorreq = form.save()
            if majorreq is None:
                messages.success(request, 'Major Requirement "{}" was created.'.format(update_majorreq))
            else:
                messages.success(request, 'Major Requirement "{}" was updated.'.format(update_majorreq))

            return redirect("majorreq_edit",update_majorreq.pk)
    else:
        form = MajorReqForm(instance=majorreq)

    return render(request, "checklist/instance-form.html", {"method": request.method, "form":form, "model_type": "Major_requirement", "instance": majorreq,})

# Degree courses selection form
# def course_form(request):
#     if request.method == "POST":
#         form = CourseForm(request.POST)
#         if form.is_valid():
#             for name, value in form.cleaned_data.items():
#                 print("{}: ({}) {}".format(name, type(value), value))
#     else:
#         form = CourseForm()
#     return render(request, 'course_form.html', {'method':request.method, "form":form})